# dog_ninja
### สร้างเกมง่ายด้วยภาษาJAVA
>method main อยู่ที่ src/display/Game.java

![Image](http://www.todostudent.com/img/Untitled.png)


_ติดต่อ : dragon123789555@gmail.com_
